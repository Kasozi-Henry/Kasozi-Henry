function showDashboard() {
  document.getElementById("membership").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
}